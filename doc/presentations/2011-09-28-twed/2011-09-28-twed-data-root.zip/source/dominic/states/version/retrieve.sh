#!/bin/bash
#
# Script to retrieve and convert a new version of the dataset.
# See https://github.com/timrdf/csv2rdf4lod-automation/wiki/Automated-creation-of-a-new-Versioned-Dataset

export CSV2RDF4LOD_CONVERT_OMIT_RAW_LAYER="true"
google2source.sh -w 0Al9lLCZTXJQ2dDlRSDQ0Uy1fRDYtNEZRUE9DTTgxQkE auto
